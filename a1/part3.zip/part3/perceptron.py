import random
import textwrap
import sys

featrue_num = 50


class Feature:
    def __init__(self, image):
        self.row = []
        self.col = []
        self.sgn = []
        self.image = image
        for i in range(4):
            self.row.append(random.randint(0, 9))
            self.col.append(random.randint(0, 9))
            self.sgn.append(random.randint(0, 1))
            if self.image is None:
                self.input = 1
            sum = 0
            for i in range(len(self.row)):
                if int(self.image.pixels[self.row[i]][self.col[i]]) == self.sgn[i]:
                    sum += 1
            if sum >= 3:
               self.input = 1
            else:
                self.input = 0
            print('featrue ',i+1,':',self.input)

class Image:
    def __init__(self):
        self.output = None
        self.width = None
        self.height = None
        self.pixels = []
        self.features = None

def train(images, weights):
    match = 0
    for image in images:
        sum = 0
        output = 0
        for i in range(featrue_num):
            sum += weights[i] * image.features[i].input
        if sum > 0:
            output = 1
        else:
            output = 0
        if image.output == output:
            match += 1
        else:
            for i in range(len(weights)):
                weights[i] += (image.output - output) * image.features[i].input
    print("classification accuracy = " , match/len(images))

def load_data(file):
    try:
        images = []
        with open(file, "r") as datafile:
            line = datafile.readline().rstrip()
            while line:
                if line == 'P1':
                    image = Image()
                    if datafile.readline().rstrip() == '#Yes':
                        image.output = 1
                    else:
                        image.output = 0
                    image.width, image.height = datafile.readline().rstrip().split()
                    line1 = datafile.readline().rstrip()
                    line2 = datafile.readline().rstrip()
                    pixel_string = line1 + line2
                    #because image size is 10,10.thus we divide the picture to (10 * 10) 2D boolean array
                    image.pixels = textwrap.wrap(pixel_string, 10)
                    features = []
                    for i in range(featrue_num):
                        features.append(Feature(image))
                    image.features = features
                    images.append(image)
                line = datafile.readline().rstrip()
            datafile.close()
        return images
    except Exception:
        print("open failed")

# main function
training_file_path = ".\image.data"
train_repeat = 100
images = load_data(training_file_path)
weights = []
for i in range(featrue_num):
    weights.append(random.random())
for i in range(train_repeat):
    print("train_cycle:",i+1)
    train(images, weights)
print("weights:")
for i in weights:
    print(i)