import java.io.InputStreamReader;
import java.util.*;
import org.jgap.*;
import org.jgap.gp.*;
import org.jgap.gp.function.*;
import org.jgap.gp.impl.*;
import org.jgap.gp.terminal.*;

public class part2 extends GPProblem {
	private static Variable xVar;
	private static float[] input;
	private static float[] output;

	private part2(GPConfiguration a_conf) throws InvalidConfigurationException {
		super(a_conf);
	}

	//Creates a genotype with the following function set and terminal set
	public GPGenotype create() throws InvalidConfigurationException {
		GPConfiguration conf = getGPConfiguration();
		Class[] types = {CommandGene.FloatClass };
		Class[][] argTypes = {{},};
		CommandGene[][] nodeSets = { {
				xVar = Variable.create(conf, "X", CommandGene.FloatClass),
				new Multiply(conf, CommandGene.FloatClass),
				new Divide(conf, CommandGene.FloatClass),
				new Subtract(conf, CommandGene.FloatClass),
				new Add(conf, CommandGene.FloatClass),
				new Pow(conf, CommandGene.FloatClass),
				new Terminal(conf, CommandGene.FloatClass, -4.0d, 4.0d, true) } };
		GPGenotype result = GPGenotype.randomInitialGenotype(conf, types, argTypes, nodeSets, 20, true);
		return result;
	}

	//Fitness function for evaluating the produced GP formulas
	public static class FormulaFitnessFunction extends GPFitnessFunction {
		Object[] NO_ARGS = new Object[0];
		protected double evaluate(final IGPProgram program) {
			double result = 0.0f;
			long longResult = 0;
			for (int i = 0; i < input.length; i++) {
				// Set the input values
				xVar.set(input[i]);
				long value = (long) program.execute_float(0, NO_ARGS);
				// The closer the value gets to 0 the better the algorithm.
				longResult += Math.abs(value - output[i]);
			}
			result = longResult;
			return result;
		}
	}

		//read regression file and set value for GP to get best solution
	public static void main(String[] args) throws Exception {
		input = new float[20];
		output = new float[20];
		Scanner scan = new Scanner(new InputStreamReader(ClassLoader.getSystemResourceAsStream(args[0])));
		scan.nextLine();
		scan.nextLine();
		int pos=0;
		while(scan.hasNextLine()){
			input[pos] = scan.nextFloat();
			output[pos] = scan.nextFloat();
			pos++;
		}
		// Create a GP Configuration Object,the Values for the maximum initialization depth population size
		// and maximum crossover depth come from tutorial which is good enough to figure.
		GPConfiguration config = new GPConfiguration();
		config.setGPFitnessEvaluator(new DeltaGPFitnessEvaluator());
		config.setMaxInitDepth(4);
		config.setPopulationSize(1000);
		config.setMaxCrossoverDepth(8);
		config.setFitnessFunction(new FormulaFitnessFunction());
		config.setStrictProgramCreation(true);

		config.setCrossoverProb(0.80f);
		config.setMutationProb(0.20f);
		config.setReproductionProb(0.05f);
		GPProblem problem = new part2(config);
		GPGenotype gp = problem.create();
		gp.setVerboseOutput(true);
		gp.evolve(2000);
		gp.outputSolution(gp.getAllTimeBest());
	}
}