run in terminal
Navigate to the directory called Part1
python "KNN.py" ".\iris-training.txt" ".\iris-test.txt" k
k can be any value you want. but for knn algorithm it is odd number(1,3,5,7)

parameter 1 = train data file path
parameter 2 = test data file path
parameter 3 = k value