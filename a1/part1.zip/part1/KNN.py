import sys
import math
import collections
import datetime as dt

#generator object in load_file by path
def read_data_file(path):
    try:
        with open(path, "r") as data_file:
            for line in data_file.readlines():
                yield line
    except Exception:
        print("open failed")

#make generator object to list
def load_data_from_file(path):
    data_list = []
    data_lines = read_data_file(path)
    for data_line in data_lines:
        if data_line and data_line.strip():
            data_part = [float(x) for x in data_line.split()[0:4]]
            data_part.append(data_line.split()[4])
            data_list.append(data_part)
    return data_list

# find class
def predicted(distance_irisname,k):
    k_neighbours = []
    k_neighbours = sorted(distance_irisname, key=lambda x: x[0])
    # vote
    class_votes = {}
    for x in range(k):
        # k_neightbours have k items, then calculate each votename appear return the highest number of votename
        vote = k_neighbours[x].irisname
        if vote in class_votes:
            class_votes[vote] += 1
        else:
            class_votes[vote] = 1
    sorted_votes = sorted(class_votes.items(), key=lambda x: x[1], reverse=True)
    print(sorted_votes[0][0])
    return sorted_votes[0][0]

# use euclidean_distance formula to calculate distance and put each name and distance in to one list
def calculate_euclidean_distance(training_data, test_vector, feature_ranges):
    Distance = collections.namedtuple("Distance", ['euclidean_distance', 'irisname'])
    distance_irisname = []
    for t_vector in training_data:
        distance = 0
        for x in range(len(feature_ranges)):
            distance += pow((t_vector[x] - test_vector[x]), 2) / feature_ranges[x]
        distance_irisname.append(Distance(math.sqrt(distance),t_vector[4]))
    return distance_irisname

#find accuracy in percentage
def verify_predicted(training_data, test_data, k):
    feature_ranges = []
    distance_irisname =[]
    # find four each feature(sepal length in cm, sepal width in cm, petal length in cm, and petal width in cm)
    for i in range(4):
        sorted_training_data = sorted(training_data, key=lambda tup: tup[i])
        max = sorted_training_data[-1][i]
        min = sorted_training_data[0][i]
        ranges = pow((max-min),2)
        feature_ranges.append(ranges)
    count = 0
    for test_vector in test_data:
        distance_irisname = calculate_euclidean_distance(training_data, test_vector, feature_ranges)
        irisname = predicted(distance_irisname,k)
        if irisname == test_vector[-1]:
            count += 1
    print("classification accuracy = " + str(count / len(test_data)))

# main function,take three argument.
training_file_path = sys.argv[1] if len(sys.argv) > 1 else ".\iris-training.txt"#the first argument is train data
test_file_path = sys.argv[2] if len(sys.argv) > 2 else ".\iris-test.txt"#the second argument is test data
k = int(sys.argv[3]) if len(sys.argv) > 3 else 3#the third argument is k value
training_data = load_data_from_file(training_file_path)
test_data = load_data_from_file(test_file_path)
start = dt.datetime.now()
verify_predicted(training_data, test_data, k)
end = dt.datetime.now()
print("time = " + str((end - start).microseconds) + "(microseconds)")