import sys

# define constructor for attribution object in decision tree
class AttributionObject:
    def __init__(self, index, name, count):
        self.index = index
        self.name = name
        self.count = count
    def __str__(self):
        return str({"index": self.index, "name": self.name, "count": self.count})

# Weighting the Impurities by the probability of nodes
def best_split(node):
    best_index = sys.maxsize
    best_groups = []
    best_attributes = None
    for attributes in node["attributes"]:
        dataset = node["instances"]
        left, right = list(), list()
        for row in dataset:
            if row[attributes.index] == 'false':
                left.append(row)
            else:
                right.append(row)
        groups = left, right
        Weighted_average_Impurity = 0
        for group in groups:
            Impurity = 1
            if float(len(group)) != 0:
                for value in node["classes"]:
                    p = [row[0] for row in group].count(value) / float(len(group))
                    Impurity = Impurity * p
                Weighted_average_Impurity += Impurity
        if Weighted_average_Impurity < best_index:
            best_index = Weighted_average_Impurity
            best_groups = groups
            best_attributes = attributes
    node["attributes"] = node["attributes"][:]
    node['best_index'] = best_index
    node['best_attribute'] = best_attributes
    node["attributes"].remove(best_attributes)
    left = {'attributes': node["attributes"][:], 'instances': best_groups[0],
            'classes': node["classes"], 'value': 'false', 'attr': best_attributes}
    right = {'attributes': node["attributes"][:], 'instances': best_groups[1],
             'classes': node["classes"], 'value': 'true', 'attr': best_attributes}
    node['groups'] = [left, right]
    return node

def find_result(node, row):
    if 'class' in node:
        return node['class']
    value = row[node['best_attribute'].index]
    if (value == 'true') & ('right' in node):
        return find_result(node['right'], row)
    elif ('left' in node) & (value == 'false'):
        return find_result(node['left'], row)

def train(train_file_path):
    train_data = load_data(train_file_path)
    if train_data['instances']:
        root_node = best_split(train_data)
        build_tree(root_node)
    else:
        raise Exception('no instance in root node')
    return root_node

# each node contains: instance and attributes
def build_tree(node):
    left, right = node["groups"]
    del(node["groups"])
    if len(node['attributes']) < 1 or node['best_index'] == 0:
        instances = [row[0] for row in node['instances']]
        if len(instances) < 1:
            raise Exception('no instances')
        majority = max(set(instances), key=instances.count)
        prob = instances.count(majority) / len(instances)
        node['prob'] = prob
        node['class'] = majority
    else:
        if len(left['instances']) > 0:
            node["left"] = best_split(left)
            build_tree(node["left"])
        if len(right['instances']) > 0:
            node["right"] = best_split(right)
            build_tree(node["right"])

def print_tree(node, space):

    if node is not None:
        if 'value' in node:
            print(space + node['attr'].name + " = " + node['value'])
        if 'class' in node:
            if(node['prob']==1):
                print(space + "  Class = " + node['class'] + ', prob = ' + str(node['prob']))
        space += ' '
        if 'left' in node:
            if ('instances' in node['left'] is not None) & (len(node['left']['instances']) > 0):
                print_tree(node['left'], space)
        if 'right' in node:
            if ('instances' in node['right'] is not None) & (len(node['right']['instances']) > 0):
                print_tree(node['right'], space)

# generator object in load_file by path
def load_file(path):
    try:
        with open(path, "r") as datafile:
            for line in datafile.readlines():
                yield line
    except Exception:
        print("open failed")

# make generator object to list
def load_data(path):
    lines = load_file(path)
    instances = []
    for line in lines:
        instances.append(line.split())
    index = 1
    attributes = []
    for attr in instances[1]:
        attribution_object = AttributionObject(index, attr, 0)
        attributes.append(attribution_object)
        index += 1
    return {'attributes': attributes, 'instances': instances[2:], 'classes': [data for data in instances[0]]}

# main function
run_count = int(sys.argv[1]) if len(sys.argv) > 1 else 0
file_pathes = []
show_average = False
if run_count == 0:
    display = True
    file_pathes.append([".\hepatitis-training.dat", ".\hepatitis-test.dat"])
else:
    display = False
    show_average = True
    for i in range(1, run_count + 1):
        file_pathes.append([".\hepatitis-training-run" + str(i).zfill(2) + ".dat",
                            ".\hepatitis-test-run" + str(i).zfill(2) + ".dat"])
sum = 0
run = 0
# Train and Test
for file_pair in file_pathes:
    file_size = len(file_pathes)
    test_data = load_data(file_pair[1])
    instances = [row[0] for row in test_data['instances']]
    majority = max(set(instances), key=instances.count)
    prob = instances.count(majority) / len(instances)
    if display:
        print('Baseline classifier accuracy: ' + str(prob))
    train_tree = train(file_pair[0])
    count = 0
    test_data_size = len(test_data['instances'])
    for row in test_data['instances']:
        prediction = find_result(train_tree, row)
        if prediction == row[0]:
            count += 1
    accuracy = count / test_data_size
    sum += accuracy
    run +=1
    print("Accuracy = ", accuracy)
    if (show_average)&(run == file_size):
        print('Average accuracy = ', sum / file_size)
    if display:
        print(len(test_data['classes']),"categories")
        print(len(test_data['attributes']),"attributes")
        print("read",len(train_tree['instances']), "instances")
        print_tree(train_tree, '')