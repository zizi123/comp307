go in file
javac Navie_Bayes.java
java Navie_Bayes spamLabelled.dat spamUnlabelled.dat

or

set configuration
name:Naive_Bayes
main class:Naive_Bayes
arguments:spamLabelled.dat spamUnlabelled.dat
working directory:comp307a3p2\src
