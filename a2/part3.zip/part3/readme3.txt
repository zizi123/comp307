 
 use Intellij to open part2 file
 If jgap library missing, add all jar to build path via lib folder.
