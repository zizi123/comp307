import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Naive_Bayes {
    public int spam = 0;
    public int non_spam = 0;
    public int total = 0;
    public int zero = 0;

    //true spam
    public List<Integer> l11;
    //true non-spam
    public List<Integer> l10;
    //false spam
    public List<Integer> l01;
    //false non-spam
    public List<Integer> l00;

    public Naive_Bayes(String filename,String testfilename) {

        l11 = new ArrayList<>();
        l10 = new ArrayList<>();
        l01 = new ArrayList<>();
        l00 = new ArrayList<>();

        //initial list l11,l10,l01,l00.
        for(int i=0;i<12;i++){
            l11.add(0);
            l10.add(0);
            l01.add(0);
            l00.add(0);
        }

        read(filename);
        print(l11,l10,l01,l00,spam,non_spam);
        test(testfilename);

    }

    public void print(List<Integer>l11,List<Integer>l10,List<Integer>l01,List<Integer>l00,int spam,int non_spam){
        for(int i =0;i<12;i++){
            int c = i+1;
            System.out.print("P(F"+c+" = 1| C = 1) = "+((double)l11.get(i)/spam));
            System.out.print(", P(F"+c+" = 1| C = 0) = "+((double)l10.get(i)/non_spam));
            System.out.print(", P(F"+c+" = 0| C = 1) = "+(double)l01.get(i)/spam);
            System.out.print(", P(F"+c+" = 0| C = 0) = "+(double)l00.get(i)/non_spam);
            System.out.println("\n");
        }
    }

    public void read(String filename) {
        try {
            BufferedReader br = new BufferedReader(new FileReader(filename));
            String line;
            while ((line = br.readLine()) != null && !line.isEmpty()) {
                String[] tokens = line.split("\\s+");

                if(tokens[1].equals("0")&&tokens[2].equals("0")&&tokens[3].equals("0")&&tokens[4].equals("0")&&
                        tokens[5].equals("0")&&tokens[6].equals("0")&&tokens[7].equals("0")&&tokens[8].equals("0")&&
                        tokens[9].equals("0")&&tokens[10].equals("0")&&tokens[11].equals("0")&&tokens[12].equals("0")){
                    zero+=1;
                }

                if(zero>0){
                    non_spam+=1;
                    spam+=1;
                    for (int i = 0; i < 12; i++) {
                        l11.set(i,l11.get(i)+1);
                        l01.set(i,l01.get(i)+1);
                        l10.set(i,l10.get(i)+1);
                        l00.set(i,l00.get(i)+1);
                    }
                    zero = 0;
                }

                if (tokens[13].equals("1")) {
                    spam+=1;
                    for (int i=0; i<12; i++) {
                        if (tokens[i + 1].equals("1")) {
                            l11.set(i,l11.get(i)+1);
                        } else {
                            l01.set(i,l01.get(i)+1);
                        }
                    }
                } else {
                    non_spam+=1;
                    for (int i=0;i<12; i++) {
                        if (tokens[i + 1].equals("1")) {
                            l10.set(i,l10.get(i)+1);
                        } else {
                            l00.set(i,l00.get(i)+1);
                        }
                    }
                }
            }
        }
        catch(FileNotFoundException e){
                System.out.println(e.getMessage());
            }
        catch(IOException ei){
                System.out.println(ei.getMessage());
            }
        }

    public void test(String filename){
        try {
            BufferedReader br = new BufferedReader(new FileReader(filename));
            String line;
            total =spam+non_spam;
            while ((line = br.readLine()) != null && !line.isEmpty()) {
                double result_spam=((double)spam/total);
                double result_nonspam=((double)non_spam/total);
                //Double[] l = new Double[13];
                String[] tokens = line.split("\\s+");
                for (int i = 0; i < 12; i++) {
                    if (tokens[i + 1].equals("1")) {
                        result_spam*=((double)l11.get(i) / spam);
                        result_nonspam*=((double)l10.get(i) / non_spam);
                    } else {
                        result_spam*=((double)l01.get(i) / spam);
                        result_nonspam*=((double)l00.get(i) / non_spam);
                    }
                }
                if(result_spam > result_nonspam){
                    System.out.println("Probability for Spam  is "+result_spam + " , Probability for non-spam is "+ result_nonspam+", Spam");
                }else {
                    System.out.println("Probability for Spam  is "+result_spam + " , Probability for non-spam is "+ result_nonspam+", Non_Spam");
                }
            }
        }
        catch(FileNotFoundException e){
            System.out.println(e.getMessage());
        }
        catch(IOException ei){
            System.out.println(ei.getMessage());
        }
    }
    public static void main(String[] args) {
        new Naive_Bayes(args[0],args[1]);
    }
}

