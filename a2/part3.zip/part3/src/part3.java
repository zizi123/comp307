import org.jgap.InvalidConfigurationException;
import org.jgap.gp.CommandGene;
import org.jgap.gp.GPFitnessFunction;
import org.jgap.gp.GPProblem;
import org.jgap.gp.IGPProgram;
import org.jgap.gp.function.*;
import org.jgap.gp.impl.DeltaGPFitnessEvaluator;
import org.jgap.gp.impl.GPConfiguration;
import org.jgap.gp.impl.GPGenotype;
import org.jgap.gp.terminal.Terminal;
import org.jgap.gp.terminal.Variable;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import org.jgap.util.SystemKit;

public class part3 {
    public static final Object[] NO_ARGUMENTS = new Object[0];
    private Gene problem;
    private GPConfiguration conf;
    private final parse parseFirgue;
    private final List<Patients> trainingPatients;
    private final List<Patients> testPatients;

    private part3(String training_data, String test_data) {
        parseFirgue = new parse(training_data,test_data);
        trainingPatients = parseFirgue.getTrainingPatients();
        testPatients = parseFirgue.getTestPatients();
    }

    private void Configuration() throws Exception {
        conf = new GPConfiguration();
        conf.setGPFitnessEvaluator(new DeltaGPFitnessEvaluator());
        conf.setFitnessFunction(new PatientFitnessFunction(trainingPatients));
        conf.setMaxInitDepth(4);
        conf.setPopulationSize(1000);
        conf.setMaxCrossoverDepth(8);
        conf.setStrictProgramCreation(true);
        conf.setCrossoverProb(0.8f);
        conf.setMutationProb(0.2f);
        conf.setReproductionProb(0.05f);
        Variable[] vars = parseFirgue.createVariables(conf);
        problem = new Gene(conf, vars);
    }

    private void Classification() throws Exception {
        GPGenotype gp = problem.create();
        gp.setGPConfiguration(conf);
        gp.setVerboseOutput(true);
        evolve(2000,gp);
        gp.outputSolution(gp.getAllTimeBest());

        PatientFitnessFunction train = new PatientFitnessFunction(trainingPatients);
        double training_accuracy = 100-train.evaluate(gp.getAllTimeBest()) * 100;
        System.out.println("Training set classification accuracy: " + training_accuracy + "%");

        PatientFitnessFunction test = new PatientFitnessFunction(testPatients);
        double test_accuracy = 100-test.evaluate(gp.getAllTimeBest()) * 100;
        System.out.println("Test set classification accuracy: " + test_accuracy + "%");
    }

    private void evolve(int a_evolutions, GPGenotype program) {
        int offset = program.getGPConfiguration().getGenerationNr();
        int evolutions;
        if (a_evolutions < 0) {
            evolutions = Integer.MAX_VALUE;
        } else {
            evolutions = a_evolutions;
        }
        for (int i = 0; i < evolutions; i++) {
            if (i >= 1) {
                if (program.getAllTimeBest().getFitnessValue() < 0.04) {
                    return;
                }
            }
            // Print output every 25 evolutions
            if (i % 25 == 0) {
                String freeMB = SystemKit.niceMemory(SystemKit.getFreeMemoryMB());
                System.out.println("Evolving generation " + (i + offset) + ", memory free: " + freeMB + " MB, ");
            }
            program.evolve();
            program.calcFitness();
        }
    }

    public class PatientFitnessFunction extends GPFitnessFunction {
        private List<Patients> cancers;
        public PatientFitnessFunction(List<Patients> cancers){
            this.cancers = cancers;
        }
        protected double evaluate(IGPProgram igpProgram) {
            double result = 0.0f;
            for (Patients patient : cancers) {
                problem.setPatientsVariable(patient);
                double value = igpProgram.execute_float(0, NO_ARGUMENTS);
                if (value >= 0) {
                    if (patient.getCondition()==2) {
                        result++;
                    }
                } else {
                    if (patient.getCondition()==4) {
                        result++;
                    }
                }
            }
            return result / cancers.size();
        }
    }

    public static void main(String[] args) throws Exception {
        part3 main = new part3(args[0], args[1]);
        main.Configuration();
        main.Classification();
    }
}

class parse {
    private String trainingData;
    private String testData;
    private List<Patients> trainingPatients;
    private List<Patients> testPatients;

    public parse(String trainName, String testName) {
        this.trainingData = trainName;
        this.testData = testName;
        trainingPatients = new ArrayList<>();
        testPatients = new ArrayList<>();
        Scanner scan;
        scan = new Scanner(new InputStreamReader(ClassLoader.getSystemResourceAsStream(trainingData)));
        while(scan.hasNextLine()){
            String line = scan.nextLine();
            String[] data = line.split(",");
            trainingPatients.add(new Patients(data));
        }
        scan = new Scanner(new InputStreamReader(ClassLoader.getSystemResourceAsStream(testData)));
        while(scan.hasNextLine()){
            String line = scan.nextLine();
            String[] data = line.split(",");
            testPatients.add(new Patients(data));
        }
    }

    public Variable[] createVariables(GPConfiguration conf) throws Exception {
        Variable[] variables = new Variable[9];
        variables[0]=new Variable(conf, "x1", CommandGene.FloatClass);
        variables[1]=new Variable(conf, "x2", CommandGene.FloatClass);
        variables[2]=new Variable(conf, "x3", CommandGene.FloatClass);
        variables[3]=new Variable(conf, "x4", CommandGene.FloatClass);
        variables[4]=new Variable(conf, "x5", CommandGene.FloatClass);
        variables[5]=new Variable(conf, "x6", CommandGene.FloatClass);
        variables[6]=new Variable(conf, "x7", CommandGene.FloatClass);
        variables[7]=new Variable(conf, "x8", CommandGene.FloatClass);
        variables[8]=new Variable(conf, "x9", CommandGene.FloatClass);
        return variables;
    }
    public List<Patients> getTrainingPatients() {
        return trainingPatients;
    }
    public List<Patients> getTestPatients() {
        return testPatients;
    }
}

class Gene extends GPProblem {
    private GPConfiguration conf;
    private Variable[] variables;
    public Gene(GPConfiguration conf, Variable[] variables) throws InvalidConfigurationException {
        super(conf);
        this.conf = conf;
        this.variables = variables;
    }
    public GPGenotype create() throws InvalidConfigurationException {
        Class[] types = {CommandGene.FloatClass};
        Class[][] argTypes = {{},};
        CommandGene[] mathsCommands = {
                new Multiply(conf, CommandGene.FloatClass),
                new Divide(conf, CommandGene.FloatClass),
                new Subtract(conf, CommandGene.FloatClass),
                new Add(conf, CommandGene.FloatClass),
                new Pow(conf, CommandGene.FloatClass),
                new Terminal(conf, CommandGene.FloatClass, -4.0d, 4.0d, true)};
        CommandGene[] allCommandGenes = new CommandGene[14];
        for(int i =0;i < 9;i++){
            allCommandGenes[i] = variables[i];
        }
        for(int i =9;i <14;i++) {
            allCommandGenes[i] = mathsCommands[i - 9];
        }
        CommandGene[][] nodeSets = new CommandGene[2][14];
        nodeSets[0] = allCommandGenes;
        nodeSets[1] = new CommandGene[0];
        return GPGenotype.randomInitialGenotype(conf, types, argTypes, nodeSets, 20, true);
    }

    public void setPatientsVariable(Patients patient){
        int[] patientAttributes = patient.getAttributes();
        for(int i=0;i<9;i++) {
            variables[i].set((float) patientAttributes[i]);
        }
    }
}

class Patients {
    private int[] attributes;
    private int condition;

    public Patients(String[] patientsAttributes) {
        this.attributes = new int[20];
        for(int i = 0; i< 9; i++){
            try {
                this.attributes[i] = Integer.valueOf(patientsAttributes[i]);
            } catch (NumberFormatException e) {
                this.attributes[i] = -1;
            }
        }
        try {
            condition = Integer.valueOf(patientsAttributes[10]);
        } catch (NumberFormatException e) {
            condition = -1;
        }
    }

    public int[] getAttributes() {
        return attributes;
    }
    public int getCondition() {
        return condition;
    }
}