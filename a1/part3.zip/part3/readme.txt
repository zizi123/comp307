run in terminal
Navigate to the directory called Part3

python "perceptron.py" ".\image.data" k

parameter 1 = image data file path
parameter 2 = train repeat times