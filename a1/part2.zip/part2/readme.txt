run in terminal
Navigate to the directory called Part2

python "DT.py"
python "DT.py" 10

parameter1 = how many pair of dataset do you want to run
